<title>ISSF Backend</title>
<body style="display: flex; align-items: center; justify-content: center;">
    <h1 style="font-family: sans-serif;">Welcome to ISSF</h1>
</body>
<?php /**PATH C:\Users\Tripto\Desktop\ISSF\backend\resources\views/welcome.blade.php ENDPATH**/ ?>